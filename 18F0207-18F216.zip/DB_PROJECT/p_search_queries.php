<?php
 include 'conn.php'; 
     if(isset($_POST['saveid']))
     {
       $id=$_POST['id'];
       $q = "select * from `covid-19`.`patient_tb` where id = $id ";
     }  
     else  if(isset($_POST['savename']))
              {
                $name=$_POST['p_name'];
                $q = "select * from `covid-19`.`patient_tb` where p_name = '$name' ";
                $query = mysqli_query($con,$q);
                $res = mysqli_fetch_array($query);
               }
                             else
                                 $q = "select * from `covid-19`.`patient_tb`";
               
 $query = mysqli_query($con,$q);
 ?>