<?php

include 'conn.php';

// Insert Query 

  if(isset($_POST['save']))
  {
    $w_name = $_POST['w_name'];
    $city = $_POST['city'];
    $province = $_POST['province'];
    $country = $_POST['country'];
    $total_bed = $_POST['total_bed'];
    $head_id = $_POST['head_id'];
    $q = " INSERT INTO `covid-19`.`isolation_tb`  (`w_name`, `ward_city`, `province`, `country`, `total_bed`, `head_id`) VALUES ( '$w_name', ' $city', '$province', ' $country', ' $total_bed', ' $head_id') ";
    $query = mysqli_query($con,$q);
  }

  // Update Query 
if(isset($_POST['editsave']))
{
    $id=$_GET['id'];
    $w_name = $_POST['w_name'];
    $city = $_POST['city'];
    $province = $_POST['province'];
    $country = $_POST['country'];
    $total_bed = $_POST['total_bed'];
    $head_id = $_POST['head_id'];
    $q = " update  `covid-19`.`isolation_tb` set   id='$id', w_name='$w_name', ward_city=' $city',province='$province', country='$country',total_bed=' $total_bed', head_id= ' $head_id' where id=$id";
    $query = mysqli_query($con,$q);
    header('location:isolationdisplay.php');
}

?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="UTF-8">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>

html,body,h1,h2,h3,h4 {font-family:"Lato", sans-serif}
.mySlides {display:none}
.w3-tag, .fa {cursor:pointer}
.w3-tag {height:15px;width:15px;padding:0;margin-top:6px}
.container {
  position: relative;
  width: 100%;
  max-width: 100%;
}
.container .f1 {
  position: absolute;
  top: 45%;
  left: 20%;
  color: white;
  padding-left: 20px;
  padding-right: 20px;
}
.container .f2 {
  position: absolute;
  top: 0%;
  left: 100%;
  color: white;
  padding-left: 20px;
  padding-right: 20px;
}

.container {
  position: relative;
  width: 100%;
  max-width: 100%;
}

.container img {
  width: 100%;
  height: auto;
}
.container .HOME_BUTTON {
  position: absolute;
  top: 8%;
  left: 5.5%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
 background-color:gray;
  color: white;
  font-size: 12px;
  padding: 12px 24px;
  border: none;
  cursor: pointer;
  border-radius: 5px;
  text-align: center;
}
.container .PATIENT_RECORD_BUTTON {
  position: absolute;
  top: 23.5%;
  left: 5.5%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
 background-color:gray;
  color: white;
  font-size: 12px;
  padding: 12px 24px;
  border: none;
  cursor: pointer;
  border-radius: 5px;
  text-align: center;
}
.container .ABOUT_BUTTON {
  position: absolute;
  top: 39%;
  left: 5.5%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  background-color:gray;
  color: white;
  font-size: 12px;
  padding: 12px 24px;
  border: none;
  cursor: pointer;
  border-radius: 5px;
  text-align: center;
}
.container .I_WARD_BUTTON{
  position: absolute;
  top: 55.5%;
  left: 5.5%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  background-color:black;
  color: white;
  font-size: 12px;
  padding: 12px 24px;
  border: none;
  cursor: pointer;
  border-radius: 5px;
  text-align: center;
}
.container .Q_WARD_BUTTON {
  position: absolute;
  top: 73%;
  left: 5%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  background-color:gray;
  color: white;
  font-size: 12px;
  padding: 12px 24px;
  border: none;
  cursor: pointer;
  border-radius: 5px;
  text-align: center;
}
.container .PATIENT_RECORD_BUTTON:hover {
  background-color: black;
}
.container .ABOUT_BUTTON:hover {
  background-color: black;
}
.container .I_WARD_BUTTON:hover {
  background-color: black;
}
.container .Q_WARD_BUTTON :hover {
  background-color: black;
}
.container .HOME_BUTTON:hover {
  background-color: black;
}

.I_BUTTON{
  position: absolute;
  top: 5%;
  left: 40%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  background-color:gray;
  color: white;
  font-size: 14px;
  padding: 12px 24px;
  border: none;
  cursor: pointer;
  border-radius: 5px;
  text-align: center;
}

 .S_BUTTON{
  position: absolute;
  top: 5%;
  left:53%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  background-color:gray;
  color: white;
  font-size: 14px;
  padding: 12px 24px;
  border: none;
  cursor: pointer;
  border-radius: 5px;
  text-align: center;
}
.D_BUTTON{
  position: absolute;
  top: 5%;
  left: 65%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  background-color:gray;
  color: white;
  font-size: 14px;
  padding: 12px 24px;
  border: none;
  cursor: pointer;
  border-radius: 5px;
  text-align: center;
}
.press{
  position: absolute;
  top: 50%;
  left: 350%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  background-color:gray;
  color: white;
  font-size: 12px;
  padding: 12px 24px;
  border: none;
  cursor: pointer;
  border-radius: 5px;
  text-align: center;
}
 .E_BUTTON{
  position: absolute;
  top:5%;
  left:77%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  background-color:gray;
  color: white;
  font-size: 14px;
  padding: 12px 24px;
  border: none;
  cursor: pointer;
  border-radius: 5px;
  text-align: center;
}
 .Di_BUTTON{
  position: absolute;
  top: 5%;
  left:90%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  background-color:gray;
  color: white;
  font-size: 14px;
  padding: 12px 24px;
  border: none;
  cursor: pointer;
  border-radius: 5px;
  text-align: center;
}

.I_BUTTON:hover {
  background-color: black;
}
.S_BUTTON:hover {
  background-color: black;
}
.E_BUTTON:hover {
  background-color: black;
}
.D_BUTTON:hover {
  background-color: black;
}
.Di_BUTTON:hover {
  background-color: black;
}
.container .text-block {
  position: absolute;
  
  top: 32.5%;
  left: 20%;
  color: white;
  padding-left: 20px;
  padding-right: 20px;
}
.container .live_text {
  position: absolute;
  top: 62.5%;
  left: 62%;
  color: white;
  padding-left: 20px;
  padding-right: 20px;
}
</style>
</head>
<body>


<!--  Form Input -->
<div class="container">
<img src="ISO2.jpg" alt="Snow" style="width:100%">
<!--
<div class="text-block">
<h2 class="w3-container w3-center w3-animate-top" > INSERT NEW RECORD </h2>
<h3 class="w3-container w3-center w3-animate-top">See the Realtime Pakistan COVID-19 situation! </h3>
</div>
-->
<div class="live_text">
<marquee direction="right" height="100" width="400" ><H2> COVID-19</H2> </marquee>
</div>

  <button class="HOME_BUTTON"> <a href="HOME.php"> <i class="fa fa-home w3-xxlarge" ></i> <p>HOME CVOID-19</p></a></button>
  <button class="PATIENT_RECORD_BUTTON"> <a href="PATIENT.php"><i class="fa fa-envelope w3-xxlarge"></i> <p>PATIENT RECORD</p></a></button>
	<button class="ABOUT_BUTTON"><a href="ABOUT.php"> <i class="fa fa-user w3-xxlarge"></i> <p>ABOUT CVOID-19</p></a></button>
  <button class="I_WARD_BUTTON"> <a href="ISOLATION.php"><i   class="fa fa-wheelchair-alt" style="font-size:48px"></i><p> ISOLATION  WARD </p></a></button>
  <form method="POST">
  <button class="I_BUTTON" type="submit" name="insert" > <i  style="font-size:48px"></i><p> INSERT  WARD </p></button>
  <button class="S_BUTTON" type="submit" name="search" > <i  style="font-size:48px"></i><p> SEARCH   WARD </p></button>
  <button class="D_BUTTON" type="submit" name="delete"> <i  style="font-size:48px"></i><p>DELETE WARD </p></button>
  <button class="E_BUTTON" type="submit" name="edit"> <i  style="font-size:48px"></i><p> EDIT WARD </p></button>
  <button class="Di_BUTTON" type="submit" name="dis" > <i  style="font-size:48px"></i><p> DISPLAY  WARD</p></button>
  </form>
  <button class="Q_WARD_BUTTON"> <a href="QURANTINE.php"><i class="fa fa-bed w3-xxlarge" ></i> <p>QUARANTINE WARD</p></a></button>
  <?php 
     
     if(isset($_POST['insert']))
     {
  echo "<div class='text-block'> ";
  echo " <h2 class='w3-container w3-center w3-animate-top' >INSERT NEW RECORD </h2>";
  echo "</div> ";
  echo "<form class='w3-container'  method='POST'> ";
  echo " <div class='f1'> ";
  echo " <label>Ward Name</label> ";
  echo "  <input class='w3-input w3-border w3-hover-border-black'  style='width:100%;' type='text' name='w_name' required>";
  echo " <label>City</label>";
  echo"  <input class='w3-input w3-border w3-hover-border-black' style='width:100%;' type='text' name='city' required>";
  echo " <label>Province</label> ";
  echo " <input class='w3-input w3-border w3-hover-border-black' style='width:100%;'  type='text' name='province' required>";
  echo" <button class='btn btn-success' type='submit' name='save'> Submit </button>";
  echo " <div class='f2'> ";
  echo " <label>Country</label> ";
  echo "  <input class='w3-input w3-border w3-hover-border-black' style='width:300%;' type='text' name='country' required> ";
  echo "  <label>Total_Beds</label> ";
  echo "   <input class='w3-input w3-border w3-hover-border-black' style='width:300%;' type='int' name='total_bed' required>";
  echo " <label>Head_Name</label>";
  echo " <input class='w3-input w3-border w3-hover-border-black' style='width:300%;' type='int' name='head_id' required>";
  echo "  </div> </form> </div> </div>";
}
else if(isset($_POST['delete']))
{
  echo "<div class='text-block'> ";
  echo " <h2 class='w3-container w3-center w3-animate-top' > DELETE RECORD </h2>";
  echo "</div> ";
  echo "<form class='w3-container'  action='isolationdisplay.php' method='POST'> ";
  echo " <div class='f1'> ";
  echo "<label></br>Ward  Id</br></label> "; 
   echo " <input class='w3-input w3-border w3-hover-border-black'  style='width:100%;' type='text' name='id' >";
   echo "<button class='btn btn-success' type='submit' name='saveid'> Submit </button> ";
   echo "</br> ";
   echo "<label></br>Ward  Name</br></label> ";
   echo "<input class='w3-input w3-border w3-hover-border-black'  style='width:100%;' type='text' name='w_name' > "; 
   echo " <button class='btn btn-success' type='submit' name='savename'> Submit </button>"; 
   echo "</div> </form>"; 
}
else if(isset($_POST['dis']))
{
  echo "<div class='text-block'> ";
  echo " <h2 class='w3-container w3-center w3-animate-top' > PRESS ENTER FOR DISPLAY RECORD </h2>";
  echo "</div> ";
  echo " <div class='f1'> ";
  echo "<form class='w3-container'  action='isolationdisplay.php' method='POST'> ";
  echo " <button class='press' class='btn btn-success' type='submit' name='d' style='width:100% value='Press'> ENTER </button>";
  echo "</div> </form>"; 
}
else if(isset($_POST['search']))
{
  echo "<div class='text-block'> ";
  echo " <h2 class='w3-container w3-center w3-animate-top' > SEARCH RECORD </h2>";
  echo "</div> ";
  echo "<form class='w3-container'  action='isolationdisplay.php' method='POST'> ";
  echo " <div class='f1'> ";
  echo "<label></br>Ward  Id</br></label> "; 
   echo " <input class='w3-input w3-border w3-hover-border-black'  style='width:100%;' type='text' name='id' >";
   echo "<button class='btn btn-success' type='submit' name='saveid'> SEARCH </button> ";
   echo "</br> ";
   echo" <label></br>Ward Province Name</br></label>";
   echo"<input class='w3-input w3-border w3-hover-border-black'  style='width:100%;' type='text' name='province' >";  
   echo"  <button class='btn btn-success' type='submit' name='saveprovince'>SEARCH </button>"; 
   echo " <div class='f2'> ";
   echo "<label></br>Ward_Name</br></label> ";
   echo "<input class='w3-input w3-border w3-hover-border-black'  style='width:300%;' type='text' name='w_name' > "; 
   echo " <button class='btn btn-success' type='submit' name='savename'> SEARCH </button>  </br> </div>"; 
   
   echo "</div> </form>"; 
}
else if(isset($_POST['edit']))

{
  echo "<div class='text-block'> ";
  echo " <h2 class='w3-container w3-center w3-animate-top' > EDIT RECORD </h2>";
  echo "</div> ";
  echo "<form class='w3-container'  action='isolationdisplay.php' method='POST'> ";
  echo " <div class='f1'> ";
  echo "<label></br>Ward  Id</br></label> "; 
   echo " <input class='w3-input w3-border w3-hover-border-black'  style='width:100%;' type='text' name='id' >";
   echo "<button class='btn btn-success' type='submit' name='saveid'> Submit </button> ";
   echo "</br> ";
   echo "<label></br>Ward  Name</br></label> ";
   echo "<input class='w3-input w3-border w3-hover-border-black'  style='width:100%;' type='text' name='w_name' > "; 
   echo " <button class='btn btn-success' type='submit' name='savename'> Submit </button>"; 
   echo "</div> </form>"; 
}
else
{
   
 echo "<div class='text-block'> ";
 echo " <h2 class='w3-container w3-center w3-animate-top' > EDIT  RECORD </h2>";
 echo "</div> ";
 echo "<form class='w3-container'  method='POST'> ";
 echo " <div class='f1'> ";
 echo " <label>Ward Name</label> ";
 echo "  <input class='w3-input w3-border w3-hover-border-black'  style='width:100%;' type='text' name='w_name' required>";
 echo " <label>City</label>";
 echo"  <input class='w3-input w3-border w3-hover-border-black' style='width:100%;' type='text' name='city' required>";
 echo " <label>Province</label> ";
 echo " <input class='w3-input w3-border w3-hover-border-black' style='width:100%;'  type='text' name='province' required>";
 echo" <button class='btn btn-success' type='submit' name='editsave'> Submit </button>";
 echo " <div class='f2'> ";
 echo " <label>Country</label> ";
 echo "  <input class='w3-input w3-border w3-hover-border-black' style='width:300%;' type='text' name='country' required> ";
 echo "  <label>Total_Beds</label> ";
 echo "   <input class='w3-input w3-border w3-hover-border-black' style='width:300%;' type='int' name='total_bed' required>";
 echo " <label>Head_Name</label>";
 echo " <input class='w3-input w3-border w3-hover-border-black' style='width:300%;' type='int' name='head_id' required>";
 echo "  </div> </form> </div> </div>";
}

  ?>
  
  
</body>
</html>

