<!DOCTYPE html>
<html>
<head>
 <title></title>

 <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

 <link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">
<script type="text/javascript" charset="utf8" src="https://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script>
</head>
<style>
.tb {
  position: absolute;
  top :8%;
  left:45%;
  color: black;
  padding-left: 20px;
  padding-right: 20px;
}
.tb .tb2 {
  position: absolute;
  max-width:100%;
  width :100%;
  top :100%;
  left:-80%;
  color: black;
  padding-left: 20px;
  padding-right: 20px;
}

h1  {
    text-align:center;
}
</style>
<body>
          
<form class="w3-container"  method="POST" action="isolationdisplay.php">
   <h1> Search  Isolation Ward </h1>
     </br> </br>
    <label> Which  Ward Has Contain Maximum Patient In Country </label>
    <button class="btn btn-success" type="submit" name="maxp"> Search </button>
    </br>
    <label></br> Which  Ward  Has Contain Minimum Patient In Country </label>
    <button class="btn btn-success" type="submit" name="minp"> Search </button>
     </br>
    <label></br>Which  Ward  Has Contain Maximum Patient In Province </label>
    <button class="btn btn-success" type="submit" name="maxpp"> Search </button>
    </br>
    <label> </br>Which  Ward Has Contain Minimum Patient In Province  </label>
    <button class="btn btn-success" type="submit" name="minpp"> Search </button>
    

  
   <div class="tb">
   </br></br>
    <label>    Ward  In Country </label>
    <button class="btn btn-success" type="submit" name="gbyc"> Search </button>
    
    <label> Total   No of Ward  In Country </label>
    <button class="btn btn-success" type="submit" name="cgbyc"> Search </button>
    </br></br>
    <label> Ward  In Province </label>
    <button class="btn btn-success" type="submit" name="gbyp"> Search </button>
    
    <label> Total   No of Ward  In Province </label>
    <button class="btn btn-success" type="submit" name="cgbyp"> Search </button>
    </br>
   <label></br>Ward  Id</br></label>
    <input class="w3-input w3-border w3-hover-border-black"  style="width:58%;" type="text" name="id" >
    <button class="btn btn-success" type="submit" name="saveid"> Search </button>
    </br>
    <label></br>Ward  Name</br></label>
    <input class="w3-input w3-border w3-hover-border-black"  style="width:50%;" type="text" name="w_name" >
    <button class="btn btn-success" type="submit" name="savename"> Search </button>
     </br>
     <label></br>Ward Province  Name</br></label>
    <input class="w3-input w3-border w3-hover-border-black"  style="width:50%;" type="text" name="province" >
    <button class="btn btn-success" type="submit" name="saveprovince">Search </button>
</form>
 
</div>
 

</body>
</html>