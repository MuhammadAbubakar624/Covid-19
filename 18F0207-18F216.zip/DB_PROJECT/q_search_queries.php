<?php
 include 'conn.php'; 
     if(isset($_POST['saveid']))
     {
       $name=$_POST['id'];
       $q = "select * from `covid-19`.`quarantine_tb` where id = $name ";
       $query = mysqli_query($con,$q);
       $res = mysqli_fetch_array($query);
     }  
     else  if(isset($_POST['savename']))
              {
                $name=$_POST['w_name'];
                $q = "select * from `covid-19`.`quarantine_tb` where w_name = '$name' ";
                $query = mysqli_query($con,$q);
                $res = mysqli_fetch_array($query);
               }
           
       else   if(isset($_POST['saveprovince']))
                {
                     $name=$_POST['province'];
                     $q = "select * from `covid-19`.`quarantine_tb` where province = '$name' ";
                     $query = mysqli_query($con,$q);
                     $res = mysqli_fetch_array($query);
                   }
                else   if(isset($_POST['maxp']))
                       {
                           
                           $q = "SELECT `id`, `w_name`, `province`, `country`, max(total_bed) as total_bed, `head_id`, `ward_city` FROM `quarantine_tb`` GROUP by country";
                            $query = mysqli_query($con,$q);
                                    $res = mysqli_fetch_array($query);
                          }  
                          else   if(isset($_POST['minp']))
                       {
                           
                           $q = "SELECT `id`, `w_name`, `province`, `country`, min(total_bed) as total_bed, `head_id`, `ward_city` FROM `quarantine_tb`` GROUP by country";
                            $query = mysqli_query($con,$q);
                            $res = mysqli_fetch_array($query);
                          }  
                          else   if(isset($_POST['maxpp']))
                          {
                              
                              $q = "SELECT `id`, `w_name`, `province`, `country`, max(total_bed) as total_bed, `head_id`, `ward_city` FROM `quarantine_tb`` GROUP by province";
                               $query = mysqli_query($con,$q);
                                    $res = mysqli_fetch_array($query);
                             }  
                             else   if(isset($_POST['minpp']))
                          {
                              
                              $q = "SELECT `id`, `w_name`, `province`, `country`, min(total_bed) as total_bed, `head_id`, `ward_city` FROM `quarantine_tb` GROUP by province";
                              $query = mysqli_query($con,$q);
                                    $res = mysqli_fetch_array($query);
                             }  
                             else   if(isset($_POST['gbyc']))
                             {
                              $q = "select * from `covid-19`.`quarantine_tb` group  by country ";
                                  $query = mysqli_query($con,$q);
                                    $res = mysqli_fetch_array($query);
                               }
                                  
                                  else   if(isset($_POST['gbyp']))
                                  {
                                    $q = "select * from `covid-19`.`quarantine_tb` group  by province ";
                                  $query = mysqli_query($con,$q);
                                    $res = mysqli_fetch_array($query);
                                  }
                                
                             else
                                 $q = "select * from `covid-19`.`quarantine_tb`";
               
 $query = mysqli_query($con,$q);
 ?>