<?php

include 'conn.php';

// Insert Query 

  if(isset($_POST['save']))
  {
    $p_name = $_POST['p_name'];
    $age = $_POST['age'];
    $gender= $_POST['gender'];
    $phno= $_POST['phno'];
    $city = $_POST['city'];
    $province = $_POST['province'];
    $result = $_POST['result'];
    $country = $_POST['country'];
    $ward_id = $_POST['ward_id'];
    $ward_placement=$_POST['ward_placement'];
    $date = $_POST['date'];
    $p_stuts = $_POST['p_stuts'];
    $p_condition= $_POST['p_condition'];
    $q=" INSERT INTO `covid-19`.`patient_tb` (`id`, `p_name`, `age`, `gender`, `city`, `province`, `country`, `ward_id`, `p_condition`, `p_stuts`, `date`, `ward_placement`, `phno`, `result`) VALUES (NULL, '$p_name', '$age', '$gender', '$city', ' $province', '$country','$ward_id', '$p_condition', '$p_stuts', '$date','$ward_placement', '$phno','$result')";
    $query = mysqli_query($con,$q);   
  }
   // Update Query 
if(isset($_POST['editsave']))
{
    $id=$_GET['id'];
    $p_name = $_POST['p_name'];
    $age = $_POST['age'];
    $gender= $_POST['gender'];
    $phno= $_POST['phno'];
    $city = $_POST['city'];
    $province = $_POST['province'];
    $result = $_POST['result'];
    $country = $_POST['country'];
    $ward_id = $_POST['ward_id'];
    $ward_placement=$_POST['ward_placement'];
    $date = $_POST['date'];
    $p_stuts = $_POST['p_stuts'];
    $p_condition= $_POST['p_condition'];
    $q = " update  `covid-19`.`patient_tb` set   id='$id',  p_name='$p_name', age='$age', gender='$gender',  phno='$phno', city=' $city', province=' $province', result=' $result', country=' $country', ward_id='$ward_id', ward_placement='$ward_placement', date='$date', p_stuts=' $p_stuts', p_condition='  $p_condition' where id=$id";
    $query = mysqli_query($con,$q);   
    header('location:patientdisplay.php');
}
  
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="UTF-8">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>

html,body,h1,h2,h3,h4 {font-family:"Lato", sans-serif}
.mySlides {display:none}
.w3-tag, .fa {cursor:pointer}
.w3-tag {height:15px;width:15px;padding:0;margin-top:6px}
.container {
  position: relative;
  width: 100%;
  max-width: 100%;
}
.container .f1 {
  position: absolute;
  top: 30%;
  left: 25%;
  color: white;
  padding-left: 20px;
  padding-right: 20px;
}
.container .f2 {
  position: absolute;
  top: 0%;
  left: 140%;
  color: white;
  padding-left: 20px;
  padding-right: 20px;
}

.container {
  position: relative;
  width: 100%;
  max-width: 100%;
}

.container img {
  width: 100%;
  height: auto;
}
.container .HOME_BUTTON {
  position: absolute;
  top: 8%;
  left: 5.5%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
 background-color:gray;
  color: white;
  font-size: 12px;
  padding: 12px 24px;
  border: none;
  cursor: pointer;
  border-radius: 5px;
  text-align: center;
}
.container .PATIENT_RECORD_BUTTON {
  position: absolute;
  top: 22.3%;
  left: 5.5%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
 background-color:black;
  color: white;
  font-size: 12px;
  padding: 12px 24px;
  border: none;
  cursor: pointer;
  border-radius: 5px;
  text-align: center;
}
.container .ABOUT_BUTTON {
  position: absolute;
  top: 38.7%;
  left: 5.5%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  background-color:gray;
  color: white;
  font-size: 12px;
  padding: 12px 24px;
  border: none;
  cursor: pointer;
  border-radius: 5px;
  text-align: center;
}
.container .I_WARD_BUTTON{
  position: absolute;
  top: 55%;
  left: 5.5%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  background-color:gray;
  color: white;
  font-size: 12px;
  padding: 12px 24px;
  border: none;
  cursor: pointer;
  border-radius: 5px;
  text-align: center;
}
.container .PATIENT_RECORD_BUTTON:hover {
  background-color: black;
}
.container .ABOUT_BUTTON:hover {
  background-color: black;
}
.container .I_WARD_BUTTON:hover {
  background-color: black;
}
.container .Q_WARD_BUTTON :hover {
  background-color: black;
}
.container .HOME_BUTTON:hover {
  background-color: black;
}
 .I_BUTTON{
  position: absolute;
  top: 5%;
  left: 40%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  background-color:gray;
  color: white;
  font-size: 14px;
  padding: 12px 24px;
  border: none;
  cursor: pointer;
  border-radius: 5px;
  text-align: center;
}

 .S_BUTTON{
  position: absolute;
  top: 5%;
  left:53%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  background-color:gray;
  color: white;
  font-size: 14px;
  padding: 12px 24px;
  border: none;
  cursor: pointer;
  border-radius: 5px;
  text-align: center;
}
.D_BUTTON{
  position: absolute;
  top: 5%;
  left: 65%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  background-color:gray;
  color: white;
  font-size: 14px;
  padding: 12px 24px;
  border: none;
  cursor: pointer;
  border-radius: 5px;
  text-align: center;
}
.press{
  position: absolute;
  top: 50%;
  left: 350%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  background-color:gray;
  color: white;
  font-size: 12px;
  padding: 12px 24px;
  border: none;
  cursor: pointer;
  border-radius: 5px;
  text-align: center;
}
 .E_BUTTON{
  position: absolute;
  top:5%;
  left:77%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  background-color:gray;
  color: white;
  font-size: 14px;
  padding: 12px 24px;
  border: none;
  cursor: pointer;
  border-radius: 5px;
  text-align: center;
}
 .Di_BUTTON{
  position: absolute;
  top: 5%;
  left:90%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  background-color:gray;
  color: white;
  font-size: 14px;
  padding: 12px 24px;
  border: none;
  cursor: pointer;
  border-radius: 5px;
  text-align: center;
}

.I_BUTTON:hover {
  background-color: black;
}
.S_BUTTON:hover {
  background-color: black;
}
.E_BUTTON:hover {
  background-color: black;
}
.D_BUTTON:hover {
  background-color: black;
}
.Di_BUTTON:hover {
  background-color: black;
}
.container .Q_WARD_BUTTON {
  position: absolute;
  top: 71%;
  left: 5%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  background-color:gray;
  color: white;
  font-size: 12px;
  padding: 12px 24px;
  border: none;
  cursor: pointer;
  border-radius: 5px;
  text-align: center;
}
.container .text-block {
  position: absolute;
  
  top:  23.5%;
  left: 30%;
  color: white;
  padding-left: 20px;
  padding-right: 20px;
}
.container .live_text {
  position: absolute;
  top: 62.5%;
  left: 62%;
  color: white;
  padding-left: 20px;
  padding-right: 20px;
}

</style>
</head>
<body>


<!--  Form Input -->
<div class="container">
<img src="P1.jpg" alt="Snow" style="width:100%">

  <button class="HOME_BUTTON"> <a href="HOME.php"> <i class="fa fa-home w3-xxlarge" ></i> <p>HOME CVOID-19</p></a></button>
  <button class="PATIENT_RECORD_BUTTON"> <a href="PATIENT.php?id=-1"><i class="fa fa-envelope w3-xxlarge"></i> <p>PATIENT RECORD</p></a></button>
	<button class="ABOUT_BUTTON"><a href="ABOUT.php"> <i class="fa fa-user w3-xxlarge"></i> <p>ABOUT CVOID-19</p></a></button>
  <button class="I_WARD_BUTTON"> <a href="ISOLATION.php?id=-1"><i   class="fa fa-wheelchair-alt" style="font-size:48px"></i><p> ISOLATION  WARD </p></a></button>
  <button class="Q_WARD_BUTTON"> <a href="QURANTINE.php?id=-1"><i class="fa fa-bed w3-xxlarge" ></i> <p>QUARANTINE WARD</p></a></button>
  <form method="POST">
  <button  class="I_BUTTON" type="submit" name="insert" > <i  style="font-size:48px"></i><p> INSERT RECORD </p></button>
  <button class="S_BUTTON" type="submit" name="search" > <i  style="font-size:48px"></i><p> SEARCH   RECORD </p></button>
  <button class="D_BUTTON" type="submit" name="delete"> <i  style="font-size:48px"></i><p>DELETE RECORD </p></button>
  <button class="E_BUTTON" type="submit" name="edit"> <i  style="font-size:48px"></i><p> EDIT RECORD </p></button>
  <button class="Di_BUTTON" type="submit" name="dis" > <i  style="font-size:48px"></i><p> DISPLAY RECORD</p></button>
  </form>
  
  <?php 
     
     if(isset($_POST['insert']))
     {


  echo "<div class='text-block'> ";
  echo " <h2 class='w3-container w3-center w3-animate-top' >INSERT NEW RECORD </h2>";
  echo "</div> ";
  echo "<form class='w3-container'  id='patient_form' name='patient_form' method='POST'> ";

  echo " <div class='f1'> ";
  //Patient Name
  echo " <label>Patient Name</label> ";
  echo "  <input class='w3-input w3-border w3-hover-border-black'  style='width:125%;' type='text' name='p_name' required>";
  //Patient Gender
  echo " <label for='gender'>Select Gender </label> ";
  echo  " <select  class='w3-input w3-border w3-hover-border-black' style='width:125%;    form='patient_form' name='gender'>";
  echo " <option selected>Select Gender</option> ";
  echo " <option value='Male'>Male</option>";
  echo " <option value='Female'>Female</option>";
  echo "  </select>";
  //Test Date 
  echo " <label>Test Date </label> ";
  echo "  <input class='w3-input w3-border w3-hover-border-black'  style='width:125%;' type='date' name='date' required>";
  //test result
  echo "<label for='reuslt'> Test Result</label> ";
  echo  " <select  class='w3-input w3-border w3-hover-border-black' style='width:125%;    form='patient_form' name='result'>";
  echo " <option selected>Select</option> ";
  echo " <option value='Positive'>Positive</option>";
  echo " <option value='Suspected'>Suspected</option>";
  echo " <option value='Negative'>Negative</option>";
  echo "  </select>";

  // Patient Condition
  echo " <label for='p_condition'> Patient Condition </label> ";
  echo  " <select  class='w3-input w3-border w3-hover-border-black' style='width:125%;    form='patient_form' name='p_condition'>";
  echo " <option selected>Select Condition</option> ";
  echo " <option value='Normal'>Normal</option>";
  echo " <option value='Serious'>Serious</option>";
  echo "  </select>";
  //city
  echo " <label>City</label> ";
  echo "  <input class='w3-input w3-border w3-hover-border-black'  style='width:125%;' type='text' name='city' required>";
  //country
  echo " <label>Country</label> ";
  echo " <input class='w3-input w3-border w3-hover-border-black' style='width:125%;'  type='text' name='country' required>";
  
  echo " <div class='f2'> ";
  //Ages
  echo " <label> Age</label> ";
  echo "  <input class='w3-input w3-border w3-hover-border-black'  style='width:200%;' type='NUMBER' name='age' required>";
  //Phone Number
  echo " <label>Ph:No</label> ";
  echo "  <input class='w3-input w3-border w3-hover-border-black'  style='width:200%;' type='number' name='phno' required>";
  // Ward Id
  echo " <label>Ward Id</label> ";
  echo "  <input class='w3-input w3-border w3-hover-border-black' style='width:200%;' type='number' name='ward_id' min='1' max='10' required> ";
 //ward Placement
  echo " <label for='ward_placement'>  Ward_Placement </label> ";
  echo  " <select  class='w3-input w3-border w3-hover-border-black' style='width:200%;    form='patient_form' name='ward_placement'>";
  echo " <option selected>Select Ward</option> ";
  echo " <option value='Isolation Ward'>Isolation Ward</option>";
  echo " <option value='Quarantine Ward'>Quarantine Ward</option>";
  echo "  </select>";
  //patient stuts
  echo " <label for='p_stuts'> Patient Stuts </label> ";
  echo  " <select  class='w3-input w3-border w3-hover-border-black' style='width:200%;    form='patient_form' name='p_stuts'>";
  echo " <option selected>Select Patient Stuts</option> ";
  echo " <option value='Alive'>Alive</option>";
  echo " <option value='Dead'>Dead</option>";
  echo " <option value='Recovered'>Recovered</option>";
  echo "  </select>";
  //Province
  echo " <label>Province</label>";
  echo"  <input class='w3-input w3-border w3-hover-border-black' style='width:200%;' type='text' name='province' required>";
  echo " <br> ";
  echo" <button class='btn btn-success' type='submit' name='save'>Submit_Recored </button>";
  echo "  </div> </form> </div> </div>";
}
else if(isset($_POST['delete']))
{
  echo "<div class='text-block'> ";
  echo " <h2 class='w3-container w3-center w3-animate-top' > DELETE RECORD </h2>";
  echo "</div> ";
  echo "<form class='w3-container'  action='patientdisplay.php' method='POST'> ";
  echo " <div class='f1'> ";
  echo "<label></br>Patient  Id</br></label> "; 
   echo " <input class='w3-input w3-border w3-hover-border-black'  style='width:100%;' type='text' name='id' >";
   echo "<button class='btn btn-success' type='submit' name='saveid'> SEARCH </button> ";
   echo " <div class='f2'> ";
   echo "<label></br>Patient_Name</br></label> ";
   echo "<input class='w3-input w3-border w3-hover-border-black'  style='width:300%;' type='text' name='p_name' > "; 
   echo " <button class='btn btn-success' type='submit' name='savename'> SEARCH </button>  </br> </div>"; 
}
else if(isset($_POST['dis']))
{
  echo "<div class='text-block'> ";
  echo " <h2 class='w3-container w3-center w3-animate-top' > PRESS ENTER FOR DISPLAY RECORD </h2>";
  echo "</div> ";
  echo " <div class='f1'> ";
  echo "<form class='w3-container'  action='patientdisplay.php' method='POST'> ";
  echo " <br> <br><br> <br>";
  echo " <button class='press' class='btn btn-success' type='submit' name='d' style='width:100% value='Press'> ENTER </button>";
  echo "</div> </form>"; 
}
else if(isset($_POST['search']))
{
  echo "<div class='text-block'> ";
  echo " <h2 class='w3-container w3-center w3-animate-top' > SEARCH RECORD </h2>";
  echo "</div> ";
  echo "<form class='w3-container'  action='patientdisplay.php' method='POST'> ";
  echo " <div class='f1'> ";
  echo "<label></br>Patient  Id</br></label> "; 
   echo " <input class='w3-input w3-border w3-hover-border-black'  style='width:100%;' type='text' name='id' >";
   echo "<button class='btn btn-success' type='submit' name='saveid'> SEARCH </button> ";
   echo " <div class='f2'> ";
   echo "<label></br>Patient_Name</br></label> ";
   echo "<input class='w3-input w3-border w3-hover-border-black'  style='width:300%;' type='text' name='p_name' > "; 
   echo " <button class='btn btn-success' type='submit' name='savename'> SEARCH </button>  </br> </div>"; 
   echo "</div> </form>"; 
}
else
{
  echo "<div class='text-block'> ";
  echo " <h2 class='w3-container w3-center w3-animate-top' >EDIT RECORD </h2>";
  echo "</div> ";
  echo "<form class='w3-container'  id='patient_form' name='patient_form' method='POST'> ";

  echo " <div class='f1'> ";
  //Patient Name
  echo " <label>Patient Name</label> ";
  echo "  <input class='w3-input w3-border w3-hover-border-black'  style='width:125%;' type='text' name='p_name' required>";
  //Patient Gender
  echo " <label for='gender'>Select Gender </label> ";
  echo  " <select  class='w3-input w3-border w3-hover-border-black' style='width:125%;    form='patient_form' name='gender'>";
  echo " <option selected>Select Gender</option> ";
  echo " <option value='Male'>Male</option>";
  echo " <option value='Female'>Female</option>";
  echo "  </select>";
  //Test Date 
  echo " <label>Test Date </label> ";
  echo "  <input class='w3-input w3-border w3-hover-border-black'  style='width:125%;' type='date' name='date' required>";
  //test result
  echo "<label for='reuslt'> Test Result</label> ";
  echo  " <select  class='w3-input w3-border w3-hover-border-black' style='width:125%;    form='patient_form' name='result'>";
  echo " <option selected>Select</option> ";
  echo " <option value='Positive'>Positive</option>";
  echo " <option value='Suspected'>Suspected</option>";
  echo " <option value='Negative'>Negative</option>";
  echo "  </select>";

  // Patient Condition
  echo " <label for='p_condition'> Patient Condition </label> ";
  echo  " <select  class='w3-input w3-border w3-hover-border-black' style='width:125%;    form='patient_form' name='p_condition'>";
  echo " <option selected>Select Condition</option> ";
  echo " <option value='Normal'>Normal</option>";
  echo " <option value='Serious'>Serious</option>";
  echo "  </select>";
  //city
  echo " <label>City</label> ";
  echo "  <input class='w3-input w3-border w3-hover-border-black'  style='width:125%;' type='text' name='city' required>";
  //country
  echo " <label>Country</label> ";
  echo " <input class='w3-input w3-border w3-hover-border-black' style='width:125%;'  type='text' name='country' required>";
  
  echo " <div class='f2'> ";
  //Ages
  echo " <label> Age</label> ";
  echo "  <input class='w3-input w3-border w3-hover-border-black'  style='width:200%;' type='NUMBER' name='age' required>";
  //Phone Number
  echo " <label>Ph:No</label> ";
  echo "  <input class='w3-input w3-border w3-hover-border-black'  style='width:200%;' type='number' name='phno' required>";
  // Ward Id
  echo " <label>Ward Id</label> ";
  echo "  <input class='w3-input w3-border w3-hover-border-black' style='width:200%;' type='number' name='ward_id' min='1' max='10' required> ";
 //ward Placement
  echo " <label for='ward_placement'>  Ward_Placement </label> ";
  echo  " <select  class='w3-input w3-border w3-hover-border-black' style='width:200%;    form='patient_form' name='ward_placement'>";
  echo " <option selected>Select Ward</option> ";
  echo " <option value='Isolation Ward'>Isolation Ward</option>";
  echo " <option value='Quarantine Ward'>Quarantine Ward</option>";
  echo "  </select>";
  //patient stuts
  echo " <label for='p_stuts'> Patient Stuts </label> ";
  echo  " <select  class='w3-input w3-border w3-hover-border-black' style='width:200%;    form='patient_form' name='p_stuts'>";
  echo " <option selected>Select Patient Stuts</option> ";
  echo " <option value='Alive'>Alive</option>";
  echo " <option value='Dead'>Dead</option>";
  echo " <option value='Recovered'>Recovered</option>";
  echo "  </select>";
  //Province
  echo " <label>Province</label>";
  echo"  <input class='w3-input w3-border w3-hover-border-black' style='width:200%;' type='text' name='province' required>";
  echo " <br> ";
  echo" <button class='btn btn-success' type='submit' name='editsave'>Submit_Recored </button>";
  echo "  </div> </form> </div> </div>";
}

  ?>
  
  
</body>
</html>
