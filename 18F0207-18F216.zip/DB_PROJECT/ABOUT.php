<!doctype html>
<html lang="en">
  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="style2.css">
    <script src="https://kit.fontawesome.com/ff356d0148.js" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@600&display=swap" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="UTF-8">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<title>COVID-19</title>
  <style>
      .font-st{
    font-family: 'Open Sans', sans-serif;
    color:white;
    text-align: center;
    padding-top: 1.5%;
    height: 100px;
    background-color: #343a40;
}
.jmb-adj{
    background-image: url(img/covid-2.jpg);
    background-repeat: no-repeat;
    background-size: cover;
    background-position: center center;
    background-attachment: fixed;
    background-color: rgb(0,0,0,.6);
    background-blend-mode: overlay;
    height: 31.25rem;
    margin-top: 30px;
    
}
.back-covid{
    background-image: url(img/0.jpg);
    background-repeat: no-repeat;
    background-size: cover;
    background-position: center center;
    background-attachment: fixed;
    background-color: rgb(0,0,0,.6);
    background-blend-mode: overlay;
    color: white;
}
.back-symptoms{
    background-image: url(img/12.jpg);
    background-repeat: no-repeat;
    background-size: cover;
    background-position: center center;
    background-attachment: fixed;
    background-color: rgb(0,0,0,.6);
    background-blend-mode: overlay;
    color: white;
}
.back-prevention{
    background-image: url(img/s.jpg);
    background-repeat: no-repeat;
    background-size: cover;
    background-position: center center;
    background-attachment: fixed;
    background-color: rgb(0,0,0,.6);
    background-blend-mode: overlay;
    color: white;
}
.footer-adj{
    color: white;
    padding-top: 2.5%;
    text-align: center;
}
.container {
  background:gray;
  position: relative;
  width: 100%;
  max-width: 100%;
}

.container img {
  width: 100%;
  height: auto;
}
.container .HOME_BUTTON {
  position: absolute;
  top: 8%;
  left: 5.5%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
 background-color:gray;
  color: white;
  font-size: 12px;
  padding: 12px 24px;
  border: none;
  cursor: pointer;
  border-radius: 5px;
  text-align: center;
}
.container .ST {
  position: absolute;
  top: 90%;
  left: 5.5%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  background-color:gray;
  color: white;
  font-size: 12px;
  padding: 12px 24px;
  border: none;
  cursor: pointer;
  border-radius: 5px;
  text-align: center;
}
.container .PATIENT_RECORD_BUTTON {
  position: absolute;
  top: 23.5%;
  left: 5.5%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
 background-color:gray;
  color: white;
  font-size: 12px;
  padding: 12px 24px;
  border: none;
  cursor: pointer;
  border-radius: 5px;
  text-align: center;
}
.container .ABOUT_BUTTON {
  position: absolute;
  top: 39%;
  left: 5.5%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  background-color:black;
  color: white;
  font-size: 12px;
  padding: 12px 24px;
  border: none;
  cursor: pointer;
  border-radius: 5px;
  text-align: center;
}
.container .I_WARD_BUTTON{
  position: absolute;
  top: 55.5%;
  left: 5.5%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  background-color:gray;
  color: white;
  font-size: 12px;
  padding: 12px 24px;
  border: none;
  cursor: pointer;
  border-radius: 5px;
  text-align: center;
}
.container .Q_WARD_BUTTON {
  position: absolute;
  top: 73%;
  left: 5%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  background-color:gray;
  color: white;
  font-size: 12px;
  padding: 12px 24px;
  border: none;
  cursor: pointer;
  border-radius: 5px;
  text-align: center;
}
.container .PATIENT_RECORD_BUTTON:hover {
  background-color: black;
}
.container .ABOUT_BUTTON:hover {
  background-color: black;
}
.container .I_WARD_BUTTON:hover {
  background-color: black;
}
.container .Q_WARD_BUTTON :hover {
  background-color: black;
}
.container .HOME_BUTTON:hover {
  background-color: black;
}
.container .ST:hover {
  background-color: black;
}
.container .textblock {
  position: absolute;
  
  top: 20.5%;
  left: 15%;
  color: white;
  padding-left: 20px;
  padding-right: 20px;
}
.container .text-block {
  position: absolute;
  
  top: 30.5%;
  left: 23%;
  color: white;
  padding-left: 20px;
  padding-right: 20px;
}
.container .live_text {
  position: absolute;
  top: 62.5%;
  left: 62%;
  color: white;
  padding-left: 20px;
  padding-right: 20px;
}
.container .text_block {
  position: absolute;
  top: 45.5%;
  left: 12%;

  color: white;
  padding-left: 20px;
  padding-right: 20px;
}
.container .text_block2 {
  position: absolute;
  top: 50.5%;
  left: 35%;
  color: white;
  padding-left: 20px;
  padding-right: 20px;
}

  </style>
  </head>
  <body>



  <div class="container" >
  <img src="15.jpg" alt="Snow" style="width:100%">
    <div class="text-block" class="w3-container w3-center w3-animate-top">
   <h2 class="w3-container w3-center w3-animate-top"><i>SYMPTOMS COVID-19</i></h2>
  </div>
	<div class="text_block">
	<H3 class="w3-container w3-center w3-animate-top">Most common symptoms</H3>
	<list >
	  <li> fever</li>
    <li> dry cough</li>
    <li> tiredness</li>
    </list>
	 </br></br>
	 <H3 class="w3-container w3-center w3-animate-top">Serious symptoms</H3>
	<list >
     <li> chest pain or pressure</li>
     <li> loss of speech or movement</li>
     </list>
	</div>


	<div class="text_block2">
	<H3 class="w3-container w3-center w3-animate-top">Less common symptoms</H3>
	<list >
	<li> aches and pains</li>
    <li> sore throat</li>
     <li> diarrhoea</li>
	 <li> conjunctivitis</li>
	 <li> loss of taste or smell</li>
    </list>
	</div>
	<div class="live_text">
	<marquee direction="right" height="100" width="400" ><H2> COVID-19</H2> </marquee>
     </div>
    <button class="HOME_BUTTON"> <a href="HOME.php"> <i class="fa fa-home w3-xxlarge" ></i> <p>HOME CVOID-19</p></a></button>
   <button class="PATIENT_RECORD_BUTTON"> <a href="PATIENT.php?id=-1"><i class="fa fa-envelope w3-xxlarge"></i> <p>PATIENT RECORD</p></a></button>
	 <button class="ABOUT_BUTTON"><a href="ABOUT.php"> <i class="fa fa-user w3-xxlarge"></i> <p>ABOUT CVOID-19</p></a></button>
     <button class="I_WARD_BUTTON"> <a href="ISOLATION.php?id=-1"><i class="fa fa-wheelchair-alt" style="font-size:48px"></i><p> ISOLATION  WARD </p></a></button>
     <button class="Q_WARD_BUTTON"> <a href="QURANTINE.php?id=-1"><i class="fa fa-bed" style="font-size:48px" ></i> <p>QUARANTINE WARD</p></a></button>
     <button class="ST"> <a href="optional.php?id=-1"><<i class="fa fa-line-chart" aria-hidden="true" style="font-size:48px"></i><p> STATISTICS PAGE </p></a></button>
   </div>
</div>
                

    <div class="font-st">
      <h1>COVID-19</h1>
    </div>

        


    <div class="container-fluid">
          <div class="jumbotron jmb-adj"></div>
          </div>
    </div>


    

<div class="container-fluid">
  <div class="jumbotron back-covid">
    <h1 class="display-4">What is Coronavirus ?</h1>
    <p class="lead">Coronavirus disease (COVID-19) is an infectious disease caused by a newly discovered coronavirus.
      Most people infected with the COVID-19 virus will experience mild to moderate respiratory illness and recover without requiring special treatment.  Older people, and those with underlying medical problems like cardiovascular disease, diabetes, chronic respiratory disease, and cancer are more likely to develop serious illness.
      The best way to prevent and slow down transmission is be well informed about the COVID-19 virus, the disease it causes and how it spreads. Protect yourself and others from infection by washing your hands or using an alcohol based rub frequently and not touching your face. 
      The COVID-19 virus spreads primarily through droplets of saliva or discharge from the nose when an infected person coughs or sneezes, so it’s important that you also practice respiratory etiquette (for example, by coughing into a flexed elbow).
      At this time, there are no specific vaccines or treatments for COVID-19. However, there are many ongoing clinical trials evaluating potential treatments. WHO will continue to provide updated information as soon as clinical findings become available.</p>
  </div> 
</div>
    


<div class="container-fluid">

    <div class="jumbotron back-symptoms">
      <h1 class="display-4">Symptoms of Coronavirus</h1>
      <p class="lead">
        COVID-19 affects different people in different ways. Most infected people will develop mild to moderate illness and recover without hospitalization.
        <h6>Most common symptoms:</h6>
        <ul>
          <li>fever.</li>
          <li>dry cough.</li>
          <li>tiredness.</li>
        </ul>
        <h6>Less common symptoms:</h6>
        <ul>
          <li>aches and pains.</li>
          <li>sore throat.</li>
          <li>diarrhoea.</li>
          <li>conjunctivitis.</li>
          <li>headache.</li>
          <li>loss of taste or smell.</li>
          <li>diarrhoea.</li>
          <li>a rash on skin, or discolouration of fingers or toes.</li>
         </ul>
          <h6>Serious symptoms:</h6>
          <li>difficulty breathing or shortness of breath.</li>
          <li>chest pain or pressure.</li>
          <li>loss of speech or movement.</li>
          <br>
          <p>Seek immediate medical attention if you have serious symptoms.  Always call before visiting your doctor or health facility. 
            People with mild symptoms who are otherwise healthy should manage their symptoms at home. 
            On average it takes 5–6 days from when someone is infected with the virus for symptoms to show, however it can take up to 14 days. 
            </p>
      </p>
    </div>
</div>




<div class="container-fluid pre">

    <div class="jumbotron back-prevention">
      <h1 class="display-4">Preventions of Coronavirus</h1>
      <p class="lead">
        To prevent infection and to slow transmission of COVID-19, do the following:
      </p>
      <ul>
        <li>Wash your hands regularly with soap and water, or clean them with alcohol-based hand rub.</li>
        <li>Maintain at least 1 metre distance between you and people coughing or sneezing.</li>
        <li>Avoid touching your face. </li>
        <li>Cover your mouth and nose when coughing or sneezing. </li>
        <li>Stay home if you feel unwell. </li>
        <li>Refrain from smoking and other activities that weaken the lungs. </li>
        <li>Practice physical distancing by avoiding unnecessary travel and staying away from large groups of people. 
        </li>
      </ul>
    </div>
  
</div>

    

<div class="footer-top">
  <div class="container footer-adj">
      <div class="">
        <h3>Learn More About COVID-19</h3>
        <a class="btn btn-light" href="https://www.who.int/health-topics/coronavirus#tab=tab_2" role="button">WHO (WORLD HEALTH ORGANIZATION)</a>
      </div>
    </div>
  </div>
  
</div>
 
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
</html>