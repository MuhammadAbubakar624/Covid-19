<?php

$msg=false;
if(isset($_POST['login']))
{
    
    $u=$_POST['user'];
    $p= $_POST['pass'];
     if(!($u=='madni' and $p=='madni') and (!($u=='18F0207' and $p=='abubakar')))
     {
      $msg=true;
     }   
    else
    {
         $con = mysqli_connect('localhost',$u,$p);
         mysqli_select_db($con,'covid-19');
          header('location:HOME.php');
    }
     
}

?>

<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
<style>
  
body {
  color: #fff;
  font: 87.5%/1.5em 'Open Sans', sans-serif;
	background:url(loginn.jpg)no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;}



.form-wrapper {
width:400px;
height:450px;
  position: absolute;
  top: 50%;
  left: 48%;
  margin: -184px 0px 0px -155px;
  background: rgba(0,0,0,0.27);
  padding: 15px 25px;
  border-radius: 5px;
  box-shadow: 0px 1px 0px rgba(0,0,0,0.6),inset 0px 1px 0px rgba(255,255,255,0.04);
}

.form-item {
width:100%;
}


h3{
  font-size: 15px;
  font-weight: 640;
  color: WHITE;
  
  font-family:'sans-serif','helvetica';
}



.form-item input{
  border: none;
  background:transparent;
  color: #fff;
  margin-top:11px;
  font-family: 'Open Sans', sans-serif;
  font-size: 1.5em;
  height: 49px;
  padding: 0 16px;
  width: 100%;
  padding-left: 55px;

}
input[type='password']{
	background: transparent url("pass.jpg") no-repeat;
	background-position: 10px 50%;
}
input[type='text']{
	background: transparent url("user.jpg") no-repeat;
	background-position: 10px 50%;

}

.form-item input:focus {
  outline: none;
  border:1.4px solid #cfecf0;
}

.button-panel {
  margin-bottom: 20px;
  padding-top: 10px;
  width: 100%;
}

.button-panel .button {
  background: #00b6df;
  border: none;
  color: #fff;
  cursor: pointer;
  height: 50px;
  font-family: 'helvetica','Open Sans', sans-serif;
  font-size: 1.2em;
  text-align: center;
  text-transform: uppercase;
  transition: background 0.6s linear;
  width: 100%;
  margin-top:10px;
}

.button:hover {
  background: #6eb7cb;
}

.form-item input, .button-panel .button {
  border-radius: 2px
}

.reminder {
  text-align: center;
}

.reminder a {
  color: #fff;
  text-decoration: none;
  transition: color 0.3s;
}

.reminder a:hover {
  color: #cab6bf;
}
h2{
    text-align:center;
    font-size: 3em;
}
</style>
</head
<body>
<div class="form-wrapper">
  
  <form  method="post">
    <h2 >Login </h2>
	
    <div class="form-item">
       <h3> <label> USERNAME </labal></h3>
		<input type="text" name="user" required="required"  autofocus required></input>
    </div>
    
    <div class="form-item">
    <h3> <label> PASSWORD </labal></h3>
		<input type="password" name="pass" required="required"  required></input>
    </div>
    
    <div class="button-panel">
		<input type="submit" class="button" title="Log In" name="login" value="Login"></input>
    </div>
  </form>
    <?php
       if($msg)
       echo"  <h4>  Incorrect Username or Password </h4>";
    ?>

  
</div>

</body>
</html>