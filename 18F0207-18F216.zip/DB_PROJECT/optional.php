<?php
include 'conn.php';
$confirm=0;
if(true)
{
  $q=" select count(id) as id from `covid-19`.`patient_tb` ";
  $query = mysqli_query($con,$q);
  $confirm = mysqli_fetch_array($query);
 
  $q=" SELECT count(id) as id FROM `patient_tb` WHERE `p_stuts` LIKE 'Dead' ";
  $query = mysqli_query($con,$q);
  $dead = mysqli_fetch_array($query);
 
  $q="SELECT count(id) as id FROM `patient_tb` WHERE `p_stuts` LIKE 'Recovered' ";
  $query = mysqli_query($con,$q);
  $recovered = mysqli_fetch_array($query);
 
  $q=" SELECT count(id) as id FROM `patient_tb` WHERE `country` LIKE 'Pakistan'";
  $query = mysqli_query($con,$q);
  $pconfirm = mysqli_fetch_array($query);
 
  $q=" SELECT count(id) as id FROM `patient_tb` WHERE ( `country` LIKE 'Pakistan') and ( `p_stuts` LIKE 'Dead') ";
  $query = mysqli_query($con,$q);
  $pdead = mysqli_fetch_array($query);
 
  $q=" SELECT count(id) as id FROM `patient_tb` WHERE ( `country` LIKE 'Pakistan') and ( `p_stuts` LIKE 'Recovered') ";
  $query = mysqli_query($con,$q);
  $precovered = mysqli_fetch_array($query);

  $q=" SELECT count(id) as id FROM `patient_tb` WHERE `date` = '2020-06-14'";
  $query = mysqli_query($con,$q);
  $d1 = mysqli_fetch_array($query);
  $q=" SELECT count(id) as id FROM `patient_tb` WHERE `date` = '2020-06-15'";
  $query = mysqli_query($con,$q);
  $d2 = mysqli_fetch_array($query);
  $q=" SELECT count(id) as id FROM `patient_tb` WHERE `date` = '2020-06-16'";
  $query = mysqli_query($con,$q);
  $d3 = mysqli_fetch_array($query);

}
?>
<?php 
$c =$pconfirm['id']-$precovered['id']-$pdead['id'];
$r = $precovered['id'];
$d = $pdead['id'];
$total = $pconfirm['id'];

?>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="UTF-8">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
.container {
  position: relative;
  width: 100%;
  max-width: 100%;
}

.container img {
  width: 100%;
  height: auto;
}
.box{
    position: absolute;
    top :14%;
    left:50%;
    width:50%;
}
.box2{
    position: absolute;
    top :120%;
    left:10%;
    width:50%;
}
.box3{
    position: absolute;
    top :170%;
    left:10%;
    width:50%;
}
.container .HOME_BUTTON {
  position: absolute;
  top: 8%;
  left: 5.5%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
 background-color:gray;
  color: white;
  font-size: 12px;
  padding: 12px 24px;
  border: none;
  cursor: pointer;
  border-radius: 5px;
  text-align: center;
}
.container .PATIENT_RECORD_BUTTON {
  position: absolute;
  top: 23.5%;
  left: 5.5%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
 background-color:gray;
  color: white;
  font-size: 12px;
  padding: 12px 24px;
  border: none;
  cursor: pointer;
  border-radius: 5px;
  text-align: center;
}
.container .ABOUT_BUTTON {
  position: absolute;
  top: 39%;
  left: 5.5%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  background-color:gray;
  color: white;
  font-size: 12px;
  padding: 12px 24px;
  border: none;
  cursor: pointer;
  border-radius: 5px;
  text-align: center;
}
.container .I_WARD_BUTTON{
  position: absolute;
  top: 55.5%;
  left: 5.5%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  background-color:gray;
  color: white;
  font-size: 12px;
  padding: 12px 24px;
  border: none;
  cursor: pointer;
  border-radius: 5px;
  text-align: center;
}
.container .Q_WARD_BUTTON {
  position: absolute;
  top: 73%;
  left: 5%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  background-color:gray;
  color: white;
  font-size: 12px;
  padding: 12px 24px;
  border: none;
  cursor: pointer;
  border-radius: 5px;
  text-align: center;
}
.container .ST {
  position: absolute;
  top: 90%;
  left: 5.5%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  background-color:black;
  color: white;
  font-size: 12px;
  padding: 12px 24px;
  border: none;
  cursor: pointer;
  border-radius: 5px;
  text-align: center;
}
.container .ST:hover {
  background-color: black;
}
.container .PATIENT_RECORD_BUTTON:hover {
  background-color: black;
}
.container .ABOUT_BUTTON:hover {
  background-color: black;
}
.container .I_WARD_BUTTON:hover {
  background-color: black;
}
.container .Q_WARD_BUTTON :hover {
  background-color: black;
}
.container .HOME_BUTTON:hover {
  background-color: black;
}
.container .text-block {
  position: absolute;
  
  top: 25.5%;
  left: 24%;
  color: white;
  padding-left: 20px;
  padding-right: 20px;
}

.cases-block {
  position: absolute;
  top: 42.5%;
  left: 17%;
  font-size:20px;
  color: black;
  padding-left: 20px;
  padding-right: 20px;
}
.cases-block2 {
  position: absolute;
  top: 42.5%;
  left: 27%;
  font-size:20px;
  color: black ;
  padding-left: 20px;
  padding-right: 20px;
}
.cases-block3 {
  position: absolute;
  top: 42.5%;
  left: 37%;
  font-size:20px;
  color: black;
  padding-left: 20px;
  padding-right: 20px;
}
.cases-block4 {
  position: absolute;
  top: 62%;
  left: 17%;
  font-size:20px;
  color: black;
  padding-left: 20px;
  padding-right: 20px;
}
.cases-block5 {
  position: absolute;
  top: 62%;
  left: 27%;
  font-size:20px;
  color: black ;
  padding-left: 20px;
  padding-right: 20px;
}
.cases-block6 {
  position: absolute;
  top: 62%;
  left: 37%;
  font-size:20px;
  color: black;
  padding-left: 20px;
  padding-right: 20px;
}
</style>
</head>
<body>


  <div class="container">
  <img src="white2.jpg" alt="Snow" style="width:100%">
  <div  class="box" id="piechart" style="width: 900px; height: 500px;"></div>
  <?php 
   echo " <div class='cases-block'>";
   echo " <h2 class='w3-container w3-center w3-animate-top'> $confirm[id] </h2>"; 
   echo " </div>";
   echo " <div class='cases-block2'>";
   echo " <h2 class='w3-container w3-center w3-animate-top'>  $recovered[id]</h2>";  
   echo " </div>";
   echo " <div class='cases-block3'>";
   echo " <h2 class='w3-container w3-center w3-animate-top'> $dead[id] </h2>"; 
   echo " </div>";
   echo " <div class='cases-block4'>";
   echo " <h2 class='w3-container w3-center w3-animate-top'> $pconfirm[id] </h2>"; 
   echo " </div>";
   echo " <div class='cases-block5'>";
   echo " <h2 class='w3-container w3-center w3-animate-top'>  $precovered[id]</h2>";  
   echo " </div>";
   echo " <div class='cases-block6'>";
   echo " <h2 class='w3-container w3-center w3-animate-top'> $pdead[id] </h2>"; 
   echo " </div>";
  ?>  
  <div  class="box" id="piechart" style="width: 600px; height: 500px;"></div>
  <button class="HOME_BUTTON"> <a href="HOME.php"> <i class="fa fa-home w3-xxlarge" ></i> <p>HOME CVOID-19</p></a></button>
  <button class="PATIENT_RECORD_BUTTON"> <a href="PATIENT.php?id=-1"><i class="fa fa-envelope w3-xxlarge"></i> <p>PATIENT RECORD</p></a></button>
	 <button class="ABOUT_BUTTON"><a href="ABOUT.php"> <i class="fa fa-user w3-xxlarge"></i> <p>ABOUT CVOID-19</p></a></button>
  <button class="I_WARD_BUTTON"> <a href="ISOLATION.php?id=-1"><i class="fa fa-wheelchair-alt" style="font-size:48px"></i><p> ISOLATION  WARD </p></a></button>
   <button class="Q_WARD_BUTTON"> <a href="QURANTINE.php?id=-1"><i class="fa fa-bed" style="font-size:48px" ></i> <p>QUARANTINE WARD</p></a></button>
   <button class="ST"> <a href="optional.php?id=-1"><<i class="fa fa-line-chart" aria-hidden="true" style="font-size:48px"></i><p> STATISTICS PAGE </p></a></button>
   <div class="box2" id="chartContainer1" style="height: 370px; width: 70%;"></div>
  
</div>


<script src="https://canvasjs.com/assets/script/canvasjs.min.js"> </script>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

     
      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['Task', 'Hours per Day'],
          ['Recoverd',       parseInt('<?php echo $r; ?>')],
          ['Treatment', parseInt('<?php echo $c; ?>')],
          ['Daeth',       parseInt('<?php echo $d; ?>')]
        ]);

        var options = {
          title: 'Total Confirmed Cases in Pakistan ' + <?php echo$total; ?>
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));

        chart.draw(data, options);
      }
    </script>
    <script type="text/javascript">
window.onload = function () {

var chart = new CanvasJS.Chart("chartContainer2", {
	theme: "light1", // "light2", "dark1", "dark2"
	animationEnabled: true, // change to true		
	title:{
		text: " Patient Chart"
	},
	data: [
	{
		// Change type to "bar", "area", "spline", "pie",etc.
		type: "column",
		dataPoints: [
			{ label: "Recoverd",  y:  parseInt('<?php echo $r; ?>')  },
			{ label: "Treatment", y: parseInt('<?php echo $c; ?>')  },
			{ label: "Daeth", y:  parseInt('<?php echo $d; ?>')  },
			{ label: "Total Cases",  y: parseInt('<?php echo $total; ?>')  }
		
		]
	}
	]
});
chart.render();

}
</script>
<script type="text/javascript">
window.onload = function () {

var chart = new CanvasJS.Chart("chartContainer1", {
	theme: "dark2", 
	animationEnabled: true, // change to true		
	title:{
		text: " Cases Report Chart"
	},
	data: [
	{
		// Change type to "bar", "area", "spline", "pie",etc.
		type: "column",
		dataPoints: [
			{ label: "2020-06-14",  y:  parseInt('<?php echo $d1['id']; ?>')  },
			{ label: "2020-06-15", y: parseInt('<?php echo $d2['id']; ?>')  },
			{ label: "2020-06-16", y:  parseInt('<?php echo $d3['id']; ?>')  }
	
		
		]
	}
	]
});
chart.render();

}
</script>
</body>
</html>
